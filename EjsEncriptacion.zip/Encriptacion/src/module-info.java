module Encriptacion {
	exports ej;

	requires jBCrypt;
	requires java.sql;
}