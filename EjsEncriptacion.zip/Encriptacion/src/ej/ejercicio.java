package ej;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Pattern;

import org.mindrot.jbcrypt.BCrypt;

public class ejercicio {

	private static final String URL = "jdbc:MySQL://localhost/";
	private static final String USER = "root";
	private static final String PWD = "";
	private static Connection c;
	private static PreparedStatement ps;

	public static void main(String[] args) {

		try {
			c = conectar("usuario");

			insertarUsuarios("cabesa@tuptm", "Keloke_777");

		} catch (SQLException e) {
			// doRollback();
			e.printStackTrace();
		}

	}

	public static Connection conectar(String nombre) throws SQLException {

		System.out.println("Conectado correctamente a la base de datos");
		return DriverManager.getConnection(URL + nombre, USER, PWD);

	}

	public static void cerrar(Connection conex) {

		if (conex != null) {
			try {
				conex.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public static void doRollback() {
		try {
			c.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void insertarUsuarios(String email, String password) throws SQLException {

		c.setAutoCommit(false);

		String passwordEnc = encriptarContraseña(password);

		ps = c.prepareStatement("INSERT INTO USUARIO VALUES ((?),(?))");
		ps.setString(1, email);

		if (validaPassword(password)) {
			ps.setString(2, passwordEnc);
		} else {
			System.out.println("Contraseña no válida");
			return;
		}

		ps.executeUpdate();

		c.commit();
		c.setAutoCommit(true);

		System.out.println("Valores insertados correctamente en la tabla");

	}

	public static String encriptarContraseña(String contraseña) {
		return BCrypt.hashpw(contraseña, BCrypt.gensalt());
	}

	public static boolean validaPassword(String password) {

		return password.matches("^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@#$%^&+=!¡¿?*()-_{}\\[\\]:;<>,.\\/|]).{8,15}$");

	}

}
