package ejsDpto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ej1 {

	private static final String URL = "jdbc:MySQL://localhost/";
	private static final String USER = "root";
	private static final String PWD = "carlosjr5";

	public static void main(String[] args) {

		try {
			establecerConex("departamento");

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static Connection establecerConex(String nombreBD) throws SQLException {

		return DriverManager.getConnection(URL + nombreBD, USER, PWD);

	}

	public static void cerrarConexion(Connection conex) {
		if (conex != null) {
			try {
				conex.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void doRollback(Connection conex) {
		try {
			conex.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void visualizarDpto(Connection conex) {

		String query = "SELECT deptno, dname FROM dept";

		try {
			Statement instruccion = (Statement) conex.createStatement();

			ResultSet resultado = instruccion.executeQuery(query);

			while (resultado.next()) {

				int numero = resultado.getInt("deptno");
				String nombre = resultado.getString("dname");

				System.out.println("Número de departamento: " + numero);
				System.out.println("Nombre de departamento: " + nombre);

			}
		} catch (SQLException e) {
			doRollback(conex);
			e.printStackTrace();
		}

	}

	public static void insert(Connection conex, String nombre, String localidad) {

		try {
			conex.setAutoCommit(false);

			PreparedStatement ps = conex.prepareStatement("INSERT INTO DPTO (deptno, dname) VALUES (?,?)",
					Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, nombre);
			ps.setString(2, localidad);

			int registrosAfectados = ps.executeUpdate();
			if (registrosAfectados > 0) {
				ResultSet rs = ps.getGeneratedKeys();
				if (rs.next()) {
					System.out.printf("departamento creado con ID=%d\n, id");
				}
			}

			conex.commit();
			conex.setAutoCommit(true);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	{

	}

}
