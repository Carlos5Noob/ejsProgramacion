package prueba;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ejemplo {

	public static void main(String[] args) {

		try {

			String user = "root";
			String pwd = "carlosjr5";
			String url = "jdbc:MySQL://localhost/agenda";

			Connection conex = DriverManager.getConnection(url, user, pwd);
			System.out.println("Se ha conectado correctamente");

			String query = "select * from contacto";
			String insert = "INSERT INTO contacto VALUES ('Messi', 'messi@messi.com')";
			String modify = "UPDATE contacto SET nombre='pepe2' WHERE nombre = 'pepe'";
			String delete = "DELETE FROM contacto WHERE nombre = 'pepe2'";

			// modificación de datos
			Statement instructionModify = (Statement) conex.createStatement();
			instructionModify.executeUpdate(modify);

			// inserción de datos
			Statement instructionInsert = (Statement) conex.createStatement();
			instructionInsert.executeUpdate(insert);

			// borrado de datos
			Statement instructionDelete = (Statement) conex.createStatement();
			instructionDelete.executeUpdate(delete);

			// consulta de datos
			Statement instructionQuery = (Statement) conex.createStatement();
			ResultSet resultado = instructionQuery.executeQuery(query);

			while (resultado.next()) {

				String nombre = resultado.getString("nombre");
				String correo = resultado.getString("correo");
				System.out.println("NOMBRE: " + nombre);
				System.out.println("CORREO: " + correo);

			}

			conex.close();
		} catch (SQLException e) {
			System.out.println(e);

		}

	}

}
