package prueba;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexionBD {

	private static final String USER = "root";
	private static final String PWD = "carlosjr5";
	private static final String URL = "jdbc:MySQL://localhost/";

	public static Connection conexToBD(String nombreDB) throws SQLException {

		return DriverManager.getConnection(URL + nombreDB, USER, PWD);

	}

	public static void closeConexBD(Connection con) {
		try {
			con.close();
		} catch (SQLException e) {
			System.out.println("Error al cerrar la conexión a BD");
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		Connection conex = null;
		try {

			conex = conexToBD("agenda");

		} catch (SQLException e) {
			System.out.println(e);
		}

	}

	public static ResultSet setQuery(Connection c, String query) throws SQLException {

		Statement instructionQuery = (Statement) c.createStatement();
		ResultSet resultado = instructionQuery.executeQuery(query);

		return resultado;

	}

}
