package ejercicios;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import prueba.ConexionBD;

public class ej1 {

	public static void main(String[] args) {

		crearFicherosBD("world");

	}

	public static void crearFicherosBD(String bd_name) {

		try {
			Connection conex = ConexionBD.conexToBD(bd_name);

			String query = "SELECT * FROM city";

			Statement instructionQuery = (Statement) conex.createStatement();
			ResultSet resultado = instructionQuery.executeQuery(query);

			while (resultado.next()) {

				String code_country = resultado.getString("CountryCode");
				String name = resultado.getString("name");
				int poblacion = resultado.getInt("population");

				File archivo = new File("C:/tmp/ej1BD/" + code_country + ".txt");

				FileWriter fw = new FileWriter(archivo);
				BufferedWriter bw = new BufferedWriter(fw);

				bw.write("Nombre: " + name + "\n");
				bw.write("Población: " + poblacion);
				bw.close();
			}

			System.out.println("Archivos creados correctamente");

			ConexionBD.closeConexBD(conex);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
