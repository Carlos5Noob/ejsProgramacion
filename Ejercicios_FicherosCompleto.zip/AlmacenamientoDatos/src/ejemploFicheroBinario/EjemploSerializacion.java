package ejemploFicheroBinario;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class EjemploSerializacion {

	public static void main(String[] args) {

		Grupo dam = new Grupo("1DAW");

		dam.agregarAlumno(new Alumno("Pepe", 33, "391293432132F"));
		dam.agregarAlumno(new Alumno("Juan", 16, "3913213H"));

		try {
			FileOutputStream fos = new FileOutputStream("C:/tmp/grupo.dat");
			ObjectOutputStream out = new ObjectOutputStream(fos);

			out.writeObject(dam);
			out.writeInt(24);
			out.writeObject(new Alumno("Oscar", 99, "42141204912R"));

			out.close();

			FileInputStream rrr = new FileInputStream("C:/tmp/grupo.dat");

			ObjectInputStream buu = new ObjectInputStream(rrr);

			System.out.println("Primer alumno: " + buu.readObject());
			System.out.println("Valor entero: " + buu.readInt());
			System.out.println("Segundo alumno: " + buu.readObject());

			buu.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
