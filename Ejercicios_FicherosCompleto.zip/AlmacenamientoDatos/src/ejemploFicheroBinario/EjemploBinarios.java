package ejemploFicheroBinario;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class EjemploBinarios {

	public static void main(String[] args) {

		try {
			File fichero = new File("C:/tmp/fichero.dat");

			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(fichero));
			BufferedInputStream bin = new BufferedInputStream(new FileInputStream(fichero));

			DataInputStream inn = new DataInputStream(bin);

			DataOutputStream out = new DataOutputStream(new FileOutputStream(fichero));

			// out.write(45);
			out.writeUTF("PROG");
			out.writeInt(1);
			out.writeDouble(7.8);
			out.close();

			FileInputStream fis = new FileInputStream(fichero);

			// int num;

//			System.out.println("Datos del archivo binario: ");
//			while ((num = fis.read()) != -1) {
//				System.out.print(num + "");
//			}
//
//			fis.close();

			DataInputStream in = new DataInputStream(fis);
			System.out.println("Valor leído de nombre: " + in.readUTF());
			System.out.println("Valor leído de entero: " + in.readInt());
			System.out.println("Valor leído de número con decimales: " + in.readDouble());
			in.close();
			fis.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		catch (IOException e) {
			e.printStackTrace();
		}

	}
}
