package ejemploFicheroBinario;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



public class Grupo implements Serializable{

	private String nombre;
	private List<Alumno> alumnos;
	
	public Grupo(String nombre) {
		this.nombre = nombre;
		this.alumnos = new ArrayList<Alumno>();
	}
	
	
	
	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public void mostrarAlumnos() {
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
	}

	public void agregarAlumno(Alumno a) {
		alumnos.add(a);
	}


	@Override
	public String toString() {
		return "Grupo [nombre=" + nombre + ", alumnos=" + alumnos + "]";
	}
	
	
	
	
	
	
}
