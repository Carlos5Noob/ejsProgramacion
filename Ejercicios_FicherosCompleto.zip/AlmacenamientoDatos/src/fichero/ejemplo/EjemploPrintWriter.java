package fichero.ejemplo;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

public class EjemploPrintWriter {

	public static void main(String[] args) {

		String fichero = "C:/tmp/ejemplo.txt";
		try {
			PrintWriter pw = new PrintWriter(new FileWriter(fichero));
			pw.print("Esto es un texto sin salto de línea");
			pw.println("NUEVO PALABRA");
			pw.println("Esto es un texto con salto de línea");
			pw.println(4.5455);
			pw.close();

		} catch (IOException e) {
			System.out.println("Problemas al escribir en el fichero");

		}

	}
}
