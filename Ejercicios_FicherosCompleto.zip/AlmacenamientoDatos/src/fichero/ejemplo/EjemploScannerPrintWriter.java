package fichero.ejemplo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class EjemploScannerPrintWriter {

	public static void main(String[] args) {

		String fichero = "C:/tmp/ficheroEnteros.txt";

		try {

			PrintWriter printWriter = new PrintWriter(fichero);

			for (int i = 1; i < 1000; i++) {
				printWriter.print(i + " ");
				if (i % 100 == 0)
					printWriter.println();
			}
			printWriter.close();
			
			Scanner scanner = new Scanner(new FileReader(fichero));

			while (scanner.hasNext()) {
				System.out.println("Valor leído: " + scanner.nextInt());
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
