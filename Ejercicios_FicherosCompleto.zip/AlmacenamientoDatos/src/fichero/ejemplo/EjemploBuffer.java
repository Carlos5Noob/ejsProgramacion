package fichero.ejemplo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EjemploBuffer {

	public static void main(String[] args) {

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("C:/tmp/test.txt"));
			BufferedWriter bw2 = new BufferedWriter(new FileWriter("C:/tmp/test2.txt"));

			BufferedReader br = new BufferedReader(new FileReader("C:/tmp/test.txt"));

			Scanner scanner = new Scanner(br);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
