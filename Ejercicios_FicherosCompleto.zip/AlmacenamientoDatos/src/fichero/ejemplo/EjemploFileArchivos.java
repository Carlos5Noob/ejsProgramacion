package fichero.ejemplo;

import java.io.File;

public class EjemploFileArchivos {

	public static void main(String[] args) {

		String directorio = ".";
		listarArchivos(directorio);

	}

	public static void listarArchivos(String rutaCarpeta) {
		File directorio = new File(rutaCarpeta);

		if (directorio.isDirectory()) {
			File[] archivos = directorio.listFiles();
			for (File f : archivos) {
				if (f.isFile())
					System.out.println(f.getName() + " - " + f.length() + " bytes");
				else
					listarSubArchivos(f);
			}
		} else {
			System.out.println("Directorio no reconocido");
		}
	}

	public static void listarSubArchivos(File rutaCarpeta) {

		File[] archivos = rutaCarpeta.listFiles();
		for (File f : archivos) {
			System.out.println(f.getName() + " - " + f.length() + " bytes");
		}
	}
}
