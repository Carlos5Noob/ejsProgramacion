package fichero.ejemplo;

import java.io.File;
import java.io.IOException;

public class EjemploFile {

	public static void main(String[] args) {

		// Crear un objeto File utilizando una cadena que representa la ruta
		File archivo1 = new File("C:/Users/CarlosChacon/Desktop/Almacenamiento_Datos_Java/archivo.txt");
		// Crear un objeto File utilizando otro objeto File como base y una cadena
		// que representa el nombre del archivo o directorio
		File directorio = new File("C:/Users/CarlosChacon/Desktop/Almacenamiento_Datos_Java");
		File archivo2 = new File(directorio, "archivo.txt");

		// ejemplo fichero
		System.out.println("******EJEMPLO FICHERO******");
		if (archivo1.exists())
			System.out.println("El fichero existe");
		else
			System.out.println("El fichero no existe");

		System.out.println("Nombre: " + archivo1.getName());
		System.out.println("Longitud: " + archivo1.length());
		System.out.println("Ruta: " + archivo1.getAbsolutePath());

		// ejemplo carpeta
		System.out.println("******EJEMPLO CARPETA******");
		if (directorio.exists())
			System.out.println("El directorio existe");
		else
			System.out.println("El directorio no existe");

		System.out.println("Nombre: " + directorio.getName());
		System.out.println("Longitud: " + directorio.length());
		System.out.println("Ruta: " + directorio.getAbsolutePath());

		// supongamos que estamos en la ruta C:\tmp\programa\java
		File carpetaActual = new File("."); // carpeta actual C:\tmp\programa\java
		File carpetaPadre = new File(".."); // carpeta superior C:\tmp\programa
		File carpetaRaiz = new File("C:/"); // estamos en la unidad C: en windows
		File carpeta1 = new File("C:/tmp/programa"); // estamos en la carpeta programa de la unidad C: de windows
		File carpeta2 = new File("../.."); // estamos en la carpeta tmp de la unidad C: de windows
		File carpeta3 = new File("../../.."); // estamos en la unidad C: de windows
		File carpeta4 = new File("../imgs"); // estamos en la carpeta tmp/programa/imgs de la unidad C: de windows

		File archivo3 = new File("../img1.png"); // C:/tmp/programa/img1.png
		File archivo4 = new File("C:/img2.png"); // C:/img2.png
		File archivo5 = new File("../../img3.png"); // C:/tmp/img3.png
		File archivo6 = new File("img4.png"); // carpeta actual C:\tmp\programa\java\img4.png
		File archivo7 = new File("imgs/img5.png"); // C:\tmp\programa\java\imgs\img5.png
		
		
		
		File archivoNuevo = new File("C:/tmp/programa/java/nuevoArchivo.txt");
		
		try {
		if (archivoNuevo.createNewFile())
			System.out.println("Archivo creado");
		else 
			System.out.println("Archivo ya existente");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		File directorio1 = new File("C:/tmp/programa/java/nuevaCarpeta");
			
		
		if (directorio1.mkdir())
			System.out.println("Directorio creado");
		else 
			System.out.println("Directorio ya existente");
		
		
		if (archivoNuevo.delete())
			System.out.println("Archivo eliminado");
		else 
			System.out.println("Archivo no encontrado");
		
		File directorio2 = new File("C:/tmp/programa/java");
		
		String [] archivos = directorio2.list();
		if (archivos != null) 
			for (String a : archivos) 
				System.out.println(a);
		else 
			System.out.println("no hay archivos en la carpeta");
			
		
		
	}
}
