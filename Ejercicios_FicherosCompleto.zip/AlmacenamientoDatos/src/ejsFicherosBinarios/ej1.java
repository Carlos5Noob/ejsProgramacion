package ejsFicherosBinarios;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;

public class ej1 {

	public static void main(String[] args) {

		try {

			String ruta = pedirRutaFichero();
			int numero = pedirNumeroAleatorio();

			FileOutputStream out = new FileOutputStream(ruta, true);

			DataOutputStream dout = new DataOutputStream(out);

			for (int i = 0; i < numero; i++) {

				dout.writeInt((int) (Math.random() * 100));

			}

			dout.flush();

			FileInputStream in = new FileInputStream(ruta);

			DataInputStream din = new DataInputStream(in);

			System.out.println("\nContenido del fichero: ");

			while (din.available() > 0) {

				System.out.println(din.readInt());
			}

			din.close();

		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static int pedirNumeroAleatorio() {

		Scanner entrada = new Scanner(System.in);

		System.out.println("¿Cuántos números quieres añadir al fichero?");

		int numero = Integer.parseInt(entrada.nextLine());

		return numero;

	}

	public static String pedirRutaFichero() {

		Scanner entrada = new Scanner(System.in);

		System.out.println("Dime la ruta del fichero al que deseas añadir números enteros: ");

		String ruta = entrada.nextLine();

		return ruta;

	}

}
