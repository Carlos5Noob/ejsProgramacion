package ejsFicherosBinarios;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class ej3 {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		int opcion;
		String nombre = "";

		do {

			System.out.println("Por favor, elija una opción entre 1 y 3: ");

			opcion = Integer.parseInt(s.nextLine());

			switch (opcion) {
			case 1:

				System.out.println(
						"Has elegido la opción para crear un fichero. Por favor, indique el nombre del fichero: ");
				nombre = s.nextLine();

				try {
					FileOutputStream out = new FileOutputStream("C:/tmp/" + nombre + ".dat");
					DataOutputStream dout = new DataOutputStream(out);

					dout.writeUTF("Carlos");
					dout.writeInt(19);
					dout.writeUTF("Jerez");
					dout.flush();
					System.out.println("Fichero creado correctamente");

				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case 2:
				System.out.println("Has elegido la opción para mostrar el fichero creado. ");

				try {

					FileInputStream in = new FileInputStream("C:/tmp/" + nombre + ".dat");
					DataInputStream din = new DataInputStream(in);

					System.out.println(din.readUTF());
					System.out.println(din.readInt());
					System.out.println(din.readUTF());

					din.close();

				} catch (IOException e) {
					System.err.println("Fichero no encontrado.");
					e.getMessage();

				}

				break;

			case 3:

				System.out.println("Has elegido finalizar el programa. ");
				break;

			default:

				System.out.println("Opción no válida, inténtelo de nuevo. \n");
				break;
			}

		} while (opcion != 3);

		s.close();
	}

}
