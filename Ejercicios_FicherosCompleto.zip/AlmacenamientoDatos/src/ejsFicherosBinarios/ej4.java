package ejsFicherosBinarios;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class ej4 {

	public static void main(String[] args) {

		String ruta = "C:/tmp/datosbeca.bin";

		// crearFichero(ruta);

		// leerDatos(ruta);

		calcularCuantia(ruta);
	}

	public static void crearFichero(String ruta) {
		Scanner s = new Scanner(System.in);

		try {

			String nombreApellido;
			String sexo;
			int edad;
			int suspensos;
			String residenciaFamiliar;

			System.out.println("Ingrese el nombre y apellido del becario:");
			nombreApellido = s.nextLine();

			do {
				System.out.println("Ingrese el sexo del becario (H/M):");
				sexo = s.nextLine();
			} while ((!sexo.equalsIgnoreCase("H")) && (!sexo.equalsIgnoreCase("M")));

			do {
				System.out.println("Ingrese la edad del becario (20-60):");
				edad = s.nextInt();
			} while ((edad < 20) && (edad > 60));

			do {
				System.out.println("Ingrese el número de suspensos del curso anterior (0-4):");
				suspensos = s.nextInt();
			} while ((suspensos < 0) && (suspensos > 4));

			do {
				System.out.println("¿La residencia es familiar? (SI/NO):");
				residenciaFamiliar = s.nextLine();
			} while ((!residenciaFamiliar.equalsIgnoreCase("SI")) && (!residenciaFamiliar.equalsIgnoreCase("NO")));

			System.out.println("Ingrese los ingresos anuales de la familia:");
			double ingresosFamiliares = s.nextDouble();

			FileOutputStream fileOutputStream = new FileOutputStream("C:/tmp/datosbeca.bin", true);
			DataOutputStream dataOutputStream = new DataOutputStream(fileOutputStream);

			dataOutputStream.writeUTF(nombreApellido);
			dataOutputStream.writeUTF(sexo);
			dataOutputStream.writeInt(edad);
			dataOutputStream.writeInt(suspensos);
			dataOutputStream.writeUTF(residenciaFamiliar);
			dataOutputStream.writeDouble(ingresosFamiliares);

			dataOutputStream.flush();
			fileOutputStream.close();

			System.out.println("Los datos del becario se han guardado correctamente en 'C:/tmp/datosbeca.bin'.");

		} catch (IOException e) {
			System.err.println("Error al leer o escribir datos: " + e.getMessage());
		}

		s.close();

	}

	public static void leerDatos(String ruta) {

		try {

			FileInputStream fileInputStream = new FileInputStream(ruta);
			DataInputStream dataInputStream = new DataInputStream(fileInputStream);

			String nombreApellido = dataInputStream.readUTF();
			String sexo = dataInputStream.readUTF();
			int edad = dataInputStream.readInt();
			int suspensos = dataInputStream.readInt();
			String residenciaFamiliar = dataInputStream.readUTF();
			double ingresosFamiliares = dataInputStream.readDouble();

			System.out.println("Nombre y apellido: " + nombreApellido);
			System.out.println("Sexo: " + sexo);
			System.out.println("Edad: " + edad);
			System.out.println("Suspensos: " + suspensos);
			System.out.println("Residencia familiar: " + residenciaFamiliar);
			System.out.println("Ingresos familiares: " + ingresosFamiliares);

			dataInputStream.close();
			fileInputStream.close();

		} catch (IOException e) {
			System.err.println("Error al leer el archivo: " + e.getMessage());
		}
	}

	public static void calcularCuantia(String ruta) {
		try {
		FileInputStream fileInputStream = new FileInputStream(ruta);
		DataInputStream dataInputStream = new DataInputStream(fileInputStream);

		while (true) {
			String nombreApellido;
			String sexo;
			int edad;
			int suspensos;
			String residenciaFamiliar;
			double ingresosFamiliares;
			double cuantiaInit = 1500;

		

				nombreApellido = dataInputStream.readUTF();
				sexo = dataInputStream.readUTF();
				edad = dataInputStream.readInt();
				suspensos = dataInputStream.readInt();
				residenciaFamiliar = dataInputStream.readUTF();
				ingresosFamiliares = dataInputStream.readDouble();

				if (ingresosFamiliares <= 12000) {
					cuantiaInit += 500;
				}

				if (edad < 23) {
					cuantiaInit += 200;
				}

				if (suspensos == 0) {
					cuantiaInit += 500;
				} else if (suspensos == 1) {
					cuantiaInit += 200;
				}

				if (residenciaFamiliar.equalsIgnoreCase("No")) {
					cuantiaInit += 1000;
				}

				System.out.println("Nombre del alumno: " + nombreApellido);
				System.out.println("Cuantía del alumno: " + cuantiaInit);
			} 
			}
		catch (IOException e) {
			e.printStackTrace();
		}

	}
}
