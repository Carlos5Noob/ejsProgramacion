package ejsFicherosBinarios;

import java.io.Serializable;

public class Vehiculo implements Serializable {

	/**
	 * identificador de unico de la clase serializable
	 */
	private static final long serialVersionUID = 2353602814109663388L;
	private String matricula;
	private String marca;
	transient private double deposito;
	private String modelo;

	public Vehiculo(String matricula, String marca, double deposito, String modelo) {
		this.marca = marca;
		this.matricula = matricula;
		this.deposito = deposito;
		this.modelo = modelo;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public double getDeposito() {
		return deposito;
	}

	public void setDeposito(double deposito) {
		this.deposito = deposito;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	@Override
	public String toString() {
		return "El vehículo tiene una matrícula " + matricula + " , su marca es " + marca
				+ " , el tamaño de su depósito es de " + deposito + "L y su modelo es " + modelo;
	}

}
