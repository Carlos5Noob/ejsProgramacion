package ejsFicherosBinarios;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class ej2 {

	public static void main(String[] args) {

		String ruta = "C:/tmp/ej2Binario.dat";

		Scanner s = new Scanner(System.in);

		System.out.println("Introduce la matricula del vehículo: ");
		String matricula = s.nextLine();
		System.out.println("Introduce la marca del vehículo: ");
		String marca = s.nextLine();
		System.out.println("Introduce el depósito del vehículo: ");
		double deposito = Double.parseDouble(s.nextLine());
		System.out.println("Introduce el modelo del vehículo: ");
		String modelo = s.nextLine();

		Vehiculo v1 = new Vehiculo(matricula, marca, deposito, modelo);

		try {
			FileOutputStream ibai = new FileOutputStream(ruta, true);
			ObjectOutputStream llanos = new ObjectOutputStream(ibai);

			llanos.writeObject(v1);

			llanos.flush();

			FileInputStream ibai2 = new FileInputStream(ruta);
			ObjectInputStream llanos2 = new ObjectInputStream(ibai2);

			leerDatos(llanos2);

			llanos2.close();

		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void leerDatos(ObjectInputStream in) throws ClassNotFoundException, IOException {

		while (true) {
			Vehiculo vehiculo = (Vehiculo) in.readObject();
			
		}

	}

}
