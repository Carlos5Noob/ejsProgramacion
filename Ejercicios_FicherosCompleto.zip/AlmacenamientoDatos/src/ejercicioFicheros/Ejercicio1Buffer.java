package ejercicioFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Ejercicio1Buffer {

	public static void main(String[] args) {

		try {
			crearLineas("C:/tmp/crearLineas.txt", 100);
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			contarLineas("C:/tmp/crearLineas.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			contarPalabras("C:/tmp/crearLineas.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void crearLineas(String ruta, int entero) throws IOException {

		BufferedWriter bw = new BufferedWriter(new PrintWriter(ruta));

		for (int i = 0; i <= entero; i++) {
			bw.write("Esta es la línea " + i);
			bw.newLine();
		}

		bw.close();

	}

	public static void contarLineas(String ruta) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(ruta));
		int cont = 0;
		String linea;
		while ((linea = br.readLine()) != null) {
			cont++;
		}
		br.close();

		System.out.println("Hay " + cont + " líneas en el documento " + ruta);
	}

	public static void contarPalabras(String ruta) throws IOException {

		int palabras = 0;
		
		FileReader fr;
		fr = new FileReader(ruta);
		BufferedReader br = new BufferedReader(fr);

		String linea;

		while ((linea = br.readLine()) != null) {
			String[] palabrasLinea = linea.split("\\s+");
			palabras += palabrasLinea.length;
		}
		br.close();

		System.out.println(ruta + " contiene " + palabras + " palabras");

	}

}
