package ejercicioFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

public class Ejercicio2Buffer {

	public static void main(String[] args) {

		pintarPrimos("C:/tmp/primos.dat.txt");
		leerPrimos("C:/tmp/primos.dat.txt");

	}

	public static void pintarPrimos(String ruta) {

		try {
			BufferedWriter bw = new BufferedWriter(new PrintWriter(ruta));

			for (int i = 1; i <= 500; i++) {
				if (esPrimo(i))
					bw.write(i + " ");
				// bw.newLine();
			}
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void leerPrimos(String ruta) {

		try {

			BufferedReader br = new BufferedReader(new FileReader(ruta));

			String linea;
			while ((linea = br.readLine()) != null) {
				System.out.println(linea);
			}

			br.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static boolean esPrimo(int numero) {
		for (int i = 2; i < numero; i++) {
			if (numero % i == 0)
				return false;

		}
		return true;
	}

}
