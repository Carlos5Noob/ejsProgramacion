package ejercicioFicheros;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Ejercicio6Buffer {

	public static void main(String[] args) {

		if (args.length != 2) {
			System.out.println(
					"Uso del programa se tiene que hacer con la siguiente llamada: Ejercicio6 Fichero palabra");
			System.exit(-1);
		}

		try {
			BufferedReader br = new BufferedReader(new FileReader(args[0]));
			String palabra = args[1];
			String linea = "";
			int i;
			int contador = 0;

			while ((linea = br.readLine()) != null) {

				while ((i = linea.indexOf(palabra)) != -1) {

					linea = linea.substring(i + palabra.length(), linea.length());
					contador++;

				}

			}

			br.close();

			System.out.println("Hay " + contador + " veces la palabra " + args[1] + " en el fichero " + args[0]);

		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

	}

}
