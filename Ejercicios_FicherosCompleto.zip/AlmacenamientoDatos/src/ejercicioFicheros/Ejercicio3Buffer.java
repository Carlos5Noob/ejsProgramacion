package ejercicioFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Ejercicio3Buffer {

	public static void main(String[] args) {

		int tamaño = args.length;

		if (tamaño != 3) {
			System.out.println("Uso del programa es: Ejercicio1 FICHERO1 FICHERO2 FICHERO_MEZCLADO");
			System.exit(-1);
		}

		try {

			String param1 = args[0];
			String param2 = args[1];
			String param3 = args[2];

			BufferedReader bffichero1 = new BufferedReader(new FileReader(param1));
			BufferedReader bffichero2 = new BufferedReader(new FileReader(param2));

			BufferedWriter bfFicheroMezcla = new BufferedWriter(new FileWriter(param3));

			String lineaFichero1 = bffichero1.readLine();
			String lineaFichero2 = bffichero2.readLine();

			while (lineaFichero1 != null || lineaFichero2 != null) {
				if (lineaFichero1 != null) {
					bfFicheroMezcla.write(lineaFichero1);
					bfFicheroMezcla.newLine();
					lineaFichero1 = bffichero1.readLine();
				}
				if (lineaFichero2 != null) {
					bfFicheroMezcla.write(lineaFichero2);
					bfFicheroMezcla.newLine();
					lineaFichero2 = bffichero2.readLine();
				}
			}

			bffichero1.close();
			bffichero2.close();
			bfFicheroMezcla.close();

			System.out.println("Archivos mezclados exitosamente en " + param3);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}