package ejercicioFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Ejercicio4Buffer {

	public static void main(String[] args) {

		int tamaño = args.length;

		if (tamaño != 2) {
			System.out.println(
					"Uso del programa se tiene que hacer con la siguiente llamada: Ejercicio 4 FICHERO_DESORDENADO");
			System.exit(-1);
		}

		try {

			String param1 = args[0];
			String param2 = args[1];

			List<String> palabras = new ArrayList<String>();

			BufferedReader br = new BufferedReader(new FileReader(param1));

			BufferedWriter bw = new BufferedWriter(new FileWriter(param2));
			
			String lineafichero1;

			while ((lineafichero1 = br.readLine()) != null) {

				palabras.add(lineafichero1);

			}

			Collections.sort(palabras);
			for (String palabra : palabras) {

				bw.write(palabra + "\n");

			}
			
			br.close();
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
