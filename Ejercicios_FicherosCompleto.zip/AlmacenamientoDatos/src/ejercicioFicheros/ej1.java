package ejercicioFicheros;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ej1 {

	public static void main(String[] args) {

		listarContenido("C:/tmp", ".txt");

	}

	public static void listarContenido(String ruta, String extension) {

		File directorio = new File(ruta);

		if (directorio.isDirectory()) {
			File[] archivos = directorio.listFiles();
			for (File file : archivos) {
				if (file.toString().endsWith(extension)) {
					System.out.println(file.getName());
				}

			}
		} else {
			System.err.println("La ruta proporcionada no es un directorio");
		}
	}

}
