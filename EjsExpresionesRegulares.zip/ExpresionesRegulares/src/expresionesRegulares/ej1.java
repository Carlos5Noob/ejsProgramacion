package expresionesRegulares;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ej1 {

	public static void main(String[] args) {

		System.out.println("Introduzca un día de la semana: ");

		Scanner s = new Scanner(System.in);

		String dia = s.nextLine();

		s.close();
		Pattern patron = Pattern.compile("lunes|martes|miercoles|jueves|viernes|sabado|domingo", Pattern.CASE_INSENSITIVE);
		Matcher texto = patron.matcher(dia);

		if (texto.matches())
			System.out.println("Día válido");
		else
			System.out.println("Día no válido");
	}

}
