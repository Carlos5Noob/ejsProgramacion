package expresionesRegulares;

public class RegExpUtil {

	public static void main(String[] args) {

		System.out.println(validaNumeroEntero("45423232"));
		System.out.println(validaNumeroEnteroPositivo("45423232"));
		System.out.println(validaNumeroEnteroNegativo("-45423232"));
		System.out.println(validaDNI("83929352F"));
		System.out.println(validaIP("192.168.1.0"));
		System.out.println(validaMatricula("8311FGAW"));
		System.out.println(validaNumeroBinario("0101001"));
		System.out.println(validaNumeroOctal("126743"));
		System.out.println(validaNumeroHexadecimal("237127F"));
		System.out.println(validaNumeroReal("32777423.231312"));
		System.out.println(validaISBN("9783482649957"));
		System.out.println(validaUsuarioTwitter("@juanpe69-pene"));
		System.out.println(validaEmail("carlosjr5noob5@gmail.com"));
	}

	/**
	 * valida si una cadena es un número entero
	 * 
	 * @param texto String que contiene el valor a validar
	 * @return true si es un número entero y false en caso contrario
	 */
	public static boolean validaNumeroEntero(String texto) {

		return texto.matches("^-?[0-9]+$");

	}

	public static boolean validaNumeroEnteroPositivo(String texto) {

		return texto.matches("^[0-9]+$");

	}

	public static boolean validaNumeroEnteroNegativo(String texto) {

		return texto.matches("^-[0-9]+$");

	}

	public static boolean validaDNI(String texto) {

		return texto.matches("[0-9]{8}[A-Z]");

	}

	public static boolean validaIP(String texto) {

		return texto.matches("[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}");

	}

	public static boolean validaMatricula(String texto) {

		return texto.matches("[0-9]{4}[A-Z]{4}");

	}

	public static boolean validaNumeroBinario(String texto) {

		return texto.matches("^[01]+$");

	}

	public static boolean validaNumeroOctal(String texto) {

		return texto.matches("^[0-7]+$");

	}

	public static boolean validaNumeroHexadecimal(String texto) {

		return texto.matches("[0-9]+[A-F]*");

	}

	public static boolean validaNumeroReal(String texto) {

		return texto.matches("[0-9]+\\.?[0-9]+");

	}

	public static boolean validaISBN(String texto) {

		return texto.matches("^(978|979)\\d{10}");

	}

	public static boolean validaUsuarioTwitter(String texto) {

		return texto.matches("^@[A-Za-z\\w-.]+$");

	}

	public static boolean validaEmail(String texto) {

		return texto.matches("^[A-Za-z\\w-]+@[A-Za-z\\w]+\\.[a-z]{2,3}$");

	}
}
