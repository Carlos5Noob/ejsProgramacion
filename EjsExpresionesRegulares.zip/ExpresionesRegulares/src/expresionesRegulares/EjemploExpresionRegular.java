package expresionesRegulares;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EjemploExpresionRegular {

	public static void main(String[] args) {

		Pattern patron = Pattern.compile("[01]+"); // Creamos el patrón: objeto de tipo Pattern
		Matcher texto = patron.matcher("00001010"); // Creamos un caso de posible acoplamiento, encaje o matching:
													// objeto de tipo Matcher
		if (texto.matches()) // Se produce "matching" o "acoplamiento"
			System.out.println("La cadena encaja con el patrón.");
		else // No se produce "matching"
			System.out.println("La cadena no encaja con el patrón.");

	}

}
